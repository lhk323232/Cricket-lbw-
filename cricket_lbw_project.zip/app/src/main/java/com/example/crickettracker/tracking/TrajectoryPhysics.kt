package com.example.crickettracker.tracking

import kotlin.math.*

object TrajectoryPhysics {
    const val DEFAULT_G = 9.81

    data class Observed2D(val u: Double, val v: Double, val t: Double)
    data class Observed3D(val x: Double, val y: Double, val z: Double, val t: Double)

    data class FitResult(
        val X0: Double,
        val Y0: Double,
        val Z0: Double,
        val Vx: Double,
        val Vy: Double,
        val Vz: Double,
        val rmsError: Double,
        val bounceTime: Double? = null,
        val bouncePoint: Observed3D? = null
    )

    fun fitFrom3D(pts: List<Observed3D>, g: Double = DEFAULT_G): FitResult? {
        if (pts.size < 4) return null
        var sT = 0.0
        var sT2 = 0.0
        val n = pts.size.toDouble()
        var sX = 0.0; var sXT = 0.0
        var sY = 0.0; var sYT = 0.0
        var sZ = 0.0; var sZT = 0.0

        for (p in pts) {
            val t = p.t
            sT += t
            sT2 += t*t
            sX += p.x
            sXT += p.x * t
            sY += p.y
            sYT += p.y * t
            val zAdj = p.z + 0.5 * g * t * t
            sZ += zAdj
            sZT += zAdj * t
        }

        val det = n * sT2 - sT * sT
        if (kotlin.math.abs(det) < 1e-9) return null
        fun solveAB(sumS: Double, sumST: Double): Pair<Double, Double> {
            val a = (sumS * sT2 - sT * sumST) / det
            val b = (n * sumST - sumS * sT) / det
            return Pair(a, b)
        }

        val (X0, Vx) = solveAB(sX, sXT)
        val (Y0, Vy) = solveAB(sY, sYT)
        val (Z0, Vz) = solveAB(sZ, sZT)

        var err2 = 0.0
        for (p in pts) {
            val t = p.t
            val xi = X0 + Vx * t
            val yi = Y0 + Vy * t
            val zi = Z0 + Vz * t - 0.5 * g * t * t
            val dx = xi - p.x; val dy = yi - p.y; val dz = zi - p.z
            err2 += dx*dx + dy*dy + dz*dz
        }
        val rms = kotlin.math.sqrt(err2 / pts.size)

        val bounceThreshold = 0.05
        var bounceTime: Double? = null
        var bouncePoint: Observed3D? = null
        for (p in pts.sortedBy { it.t }) {
            val t = p.t
            val zi = Z0 + Vz * t - 0.5 * g * t * t
            if (zi <= bounceThreshold && bounceTime == null) {
                bounceTime = t
                val xi = X0 + Vx * t
                val yi = Y0 + Vy * t
                bouncePoint = Observed3D(xi, yi, zi, t)
                break
            }
        }

        return FitResult(X0, Y0, Z0, Vx, Vy, Vz, rms, bounceTime, bouncePoint)
    }

    // Predict at stump plane X = stumpX (handles single bounce)
    fun predictAtStumpPlane(fit: FitResult, stumpX: Double, g: Double = DEFAULT_G, e: Double = 0.62): Observed3D? {
        if (kotlin.math.abs(fit.Vx) < 1e-9) return null
        val tToStump = (stumpX - fit.X0) / fit.Vx
        if (tToStump < 0) return null
        val bounceT = fit.bounceTime
        if (bounceT == null || bounceT >= tToStump) {
            val x = fit.X0 + fit.Vx * tToStump
            val y = fit.Y0 + fit.Vy * tToStump
            val z = fit.Z0 + fit.Vz * tToStump - 0.5 * g * tToStump * tToStump
            return Observed3D(x, y, z, tToStump)
        } else {
            val xb = fit.X0 + fit.Vx * bounceT
            val yb = fit.Y0 + fit.Vy * bounceT
            val zb = fit.Z0 + fit.Vz * bounceT - 0.5 * g * bounceT * bounceT
            val vzBefore = fit.Vz - g * bounceT
            val vzAfter = -vzBefore * e
            val X0b = xb; val Y0b = yb; val Z0b = kotlin.math.max(0.0, zb)
            val tPrime = (stumpX - X0b) / fit.Vx
            if (tPrime < 0) return null
            val totalT = bounceT + tPrime
            val x = X0b + fit.Vx * tPrime
            val y = Y0b + fit.Vy * tPrime
            val z = Z0b + vzAfter * tPrime - 0.5 * g * tPrime * tPrime
            return Observed3D(x, y, z, totalT)
        }
    }

    // sample trajectory in world coords between minX..maxX into N points
    fun sampleTrajectory(fit: FitResult, minX: Double, maxX: Double, n: Int = 80): List<Observed3D> {
        val pts = mutableListOf<Observed3D>()
        if (fit.Vx == 0.0) return pts
        val t0 = (minX - fit.X0) / fit.Vx
        val t1 = (maxX - fit.X0) / fit.Vx
        val step = (t1 - t0) / max(1, n-1)
        for (i in 0 until n) {
            val t = t0 + i * step
            val x = fit.X0 + fit.Vx * t
            val y = fit.Y0 + fit.Vy * t
            val z = fit.Z0 + fit.Vz * t - 0.5 * DEFAULT_G * t * t
            pts.add(Observed3D(x, y, z, t))
        }
        return pts
    }
}