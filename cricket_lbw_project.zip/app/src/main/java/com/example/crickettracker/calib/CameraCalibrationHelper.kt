package com.example.crickettracker.calib

import kotlin.math.abs

object CameraCalibrationHelper {
    fun computeHomography(worldPts: List<Pair<Double, Double>>, imgPts: List<Pair<Double, Double>>): DoubleArray? {
        val n = worldPts.size
        if (n < 4 || imgPts.size != n) return null
        val rows = 2 * n
        val A = Array(rows) { DoubleArray(9) }
        for (i in 0 until n) {
            val (X, Y) = worldPts[i]
            val (u, v) = imgPts[i]
            val row1 = 2*i
            val row2 = row1 + 1
            A[row1][0] = -X; A[row1][1] = -Y; A[row1][2] = -1.0
            A[row1][6] = u*X; A[row1][7] = u*Y; A[row1][8] = u
            A[row2][3] = -X; A[row2][4] = -Y; A[row2][5] = -1.0
            A[row2][6] = v*X; A[row2][7] = v*Y; A[row2][8] = v
        }
        val ATA = Array(9) { DoubleArray(9) }
        for (i in 0 until rows) {
            for (a in 0 until 9) {
                for (b in 0 until 9) ATA[a][b] += A[i][a] * A[i][b]
            }
        }
        var vec = DoubleArray(9) { 1.0 }
        for (iter in 0 until 80) {
            val next = DoubleArray(9)
            for (i in 0 until 9) {
                var s = 0.0
                for (j in 0 until 9) s += ATA[i][j] * vec[j]
                next[i] = s
            }
            val norm = kotlin.math.sqrt(next.sumOf { it*it })
            if (norm < 1e-12) break
            for (i in 0 until 9) vec[i] = next[i] / norm
        }
        val h = vec
        val scale = h[8]
        if (abs(scale) < 1e-12) return null
        val H = DoubleArray(9)
        for (i in 0 until 9) H[i] = h[i] / scale
        return H
    }

    fun applyHomography(H: DoubleArray, X: Double, Y: Double): Pair<Double, Double> {
        val u = H[0]*X + H[1]*Y + H[2]
        val v = H[3]*X + H[4]*Y + H[5]
        val w = H[6]*X + H[7]*Y + H[8]
        return Pair(u/w, v/w)
    }

    fun invertHomography(H: DoubleArray): DoubleArray? {
        val a = H
        val det = a[0]*(a[4]*a[8] - a[5]*a[7]) - a[1]*(a[3]*a[8] - a[5]*a[6]) + a[2]*(a[3]*a[7] - a[4]*a[6])
        if (kotlin.math.abs(det) < 1e-12) return null
        val inv = DoubleArray(9)
        inv[0] = (a[4]*a[8] - a[5]*a[7]) / det
        inv[1] = (a[2]*a[7] - a[1]*a[8]) / det
        inv[2] = (a[1]*a[5] - a[2]*a[4]) / det
        inv[3] = (a[5]*a[6] - a[3]*a[8]) / det
        inv[4] = (a[0]*a[8] - a[2]*a[6]) / det
        inv[5] = (a[2]*a[3] - a[0]*a[5]) / det
        inv[6] = (a[3]*a[7] - a[4]*a[6]) / det
        inv[7] = (a[1]*a[6] - a[0]*a[7]) / det
        inv[8] = (a[0]*a[4] - a[1]*a[3]) / det
        return inv
    }

    fun imageToGround(invH: DoubleArray, u: Double, v: Double): Pair<Double, Double> {
        val X = invH[0]*u + invH[1]*v + invH[2]
        val Y = invH[3]*u + invH[4]*v + invH[5]
        val w = invH[6]*u + invH[7]*v + invH[8]
        return Pair(X/w, Y/w)
    }
}