package com.example.crickettracker.ml

import android.content.Context
import android.graphics.Bitmap
import android.graphics.PointF
import androidx.camera.core.ImageProxy
import org.tensorflow.lite.DataType
import org.tensorflow.lite.Interpreter
import org.tensorflow.lite.support.common.FileUtil
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.roundToInt

class PadSegmentationDetector(
    context: Context,
    modelAssetPath: String = "pad_seg.tflite",
    val inputW: Int = 256,
    val inputH: Int = 256
) {
    private val interpreter: Interpreter
    private val inputTensorType: DataType
    private val isQuantized: Boolean

    init {
        val model = FileUtil.loadMappedFile(context, modelAssetPath)
        val opts = Interpreter.Options()
        interpreter = Interpreter(model, opts)
        val inputIndex = 0
        val inputShape = interpreter.getInputTensor(inputIndex).shape()
        inputTensorType = interpreter.getInputTensor(inputIndex).dataType()
        isQuantized = inputTensorType == DataType.UINT8
    }

    fun close() { interpreter.close() }

    private fun imageProxyToInputBuffer(image: ImageProxy): ByteBuffer {
        val img = imageToBitmap(image, inputW, inputH)
        val byteBuffer = if (isQuantized) {
            ByteBuffer.allocateDirect(inputW * inputH * 3).order(ByteOrder.nativeOrder())
        } else {
            ByteBuffer.allocateDirect(4 * inputW * inputH * 3).order(ByteOrder.nativeOrder())
        }
        byteBuffer.rewind()
        val pixels = IntArray(inputW * inputH)
        img.getPixels(pixels, 0, inputW, 0, 0, inputW, inputH)
        for (p in pixels) {
            val r = (p shr 16 and 0xFF)
            val g = (p shr 8 and 0xFF)
            val b = (p and 0xFF)
            if (isQuantized) {
                byteBuffer.put((r and 0xFF).toByte())
                byteBuffer.put((g and 0xFF).toByte())
                byteBuffer.put((b and 0xFF).toByte())
            } else {
                byteBuffer.putFloat(r / 255.0f)
                byteBuffer.putFloat(g / 255.0f)
                byteBuffer.putFloat(b / 255.0f)
            }
        }
        byteBuffer.rewind()
        return byteBuffer
    }

    private fun imageToBitmap(image: ImageProxy, targetW: Int, targetH: Int): Bitmap {
        val yBuffer = image.planes[0].buffer
        val uBuffer = image.planes[1].buffer
        val vBuffer = image.planes[2].buffer
        val ySize = yBuffer.remaining()
        val uSize = uBuffer.remaining()
        val vSize = vBuffer.remaining()
        val nv21 = ByteArray(ySize + uSize + vSize)
        yBuffer.get(nv21, 0, ySize)
        vBuffer.get(nv21, ySize, vSize)
        uBuffer.get(nv21, ySize + vSize, uSize)
        val yuvImage = android.graphics.YuvImage(nv21, android.graphics.ImageFormat.NV21, image.width, image.height, null)
        val out = java.io.ByteArrayOutputStream()
        yuvImage.compressToJpeg(android.graphics.Rect(0, 0, image.width, image.height), 90, out)
        val yuv = out.toByteArray()
        val bmp = android.graphics.BitmapFactory.decodeByteArray(yuv, 0, yuv.size)
        return Bitmap.createScaledBitmap(bmp, targetW, targetH, true)
    }

    fun detectImpact(image: ImageProxy, originalImageWidth: Int, originalImageHeight: Int, threshold: Float = 0.5f): PointF? {
        val input = imageProxyToInputBuffer(image)
        val outShape = interpreter.getOutputTensor(0).shape()
        val outType = interpreter.getOutputTensor(0).dataType()

        val output = Array(1) { Array(outShape[1]) { FloatArray(outShape[2]) } }
        interpreter.run(input, output)
        val mask = Array(outShape[1]) { FloatArray(outShape[2]) }
        for (y in 0 until outShape[1]) for (x in 0 until outShape[2]) mask[y][x] = output[0][y][x]

        return postprocessMask(mask, originalImageWidth, originalImageHeight, threshold)
    }

    private fun postprocessMask(mask: Array<FloatArray>, origW: Int, origH: Int, threshold: Float): PointF? {
        val h = mask.size; val w = mask[0].size
        val bin = Array(h) { IntArray(w) }
        for (y in 0 until h) for (x in 0 until w) bin[y][x] = if (mask[y][x] >= threshold) 1 else 0
        val visited = Array(h) { BooleanArray(w) }
        var bestArea = 0; var bestCx = 0.0; var bestCy = 0.0
        val stack = IntArray(h*w)
        for (yy in 0 until h) {
            for (xx in 0 until w) {
                if (bin[yy][xx] == 1 && !visited[yy][xx]) {
                    var head = 0
                    stack[head++] = yy*w + xx
                    visited[yy][xx] = true
                    var area = 0; var sx = 0; var sy = 0
                    while (head > 0) {
                        val idx = stack[--head]
                        val y = idx / w; val x = idx % w
                        area++; sx += x; sy += y
                        val nbrs = arrayOf(intArrayOf(x-1,y), intArrayOf(x+1,y), intArrayOf(x,y-1), intArrayOf(x,y+1))
                        for (n in nbrs) {
                            val nx = n[0]; val ny = n[1]
                            if (nx>=0 && nx<w && ny>=0 && ny<h && !visited[ny][nx] && bin[ny][nx]==1) {
                                visited[ny][nx] = true
                                stack[head++] = ny*w + nx
                            }
                        }
                    }
                    if (area > bestArea) {
                        bestArea = area
                        bestCx = sx.toDouble() / area.toDouble()
                        bestCy = sy.toDouble() / area.toDouble()
                    }
                }
            }
        }
        if (bestArea == 0) return null
        val cxImg = (bestCx / w.toDouble() * origW.toDouble()).toFloat()
        val cyImg = (bestCy / h.toDouble() * origH.toDouble()).toFloat()
        return PointF(cxImg, cyImg)
    }
}