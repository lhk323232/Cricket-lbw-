package com.example.crickettracker

import android.Manifest
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.view.PreviewView
import com.example.crickettracker.ui.LbwDecisionScreen
import androidx.compose.runtime.Composable

class MainActivity : ComponentActivity() {

    private val requestPermissions =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            if (granted) setupUI()
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestPermissions.launch(Manifest.permission.CAMERA)
    }

    private fun setupUI() {
        setContent {
            AppContent()
        }
    }

    @Composable
    fun AppContent() {
        // Provide a simple PreviewView to the Compose screen (it will be replaced by actual CameraX preview)
        val preview = PreviewView(this)
        LbwDecisionScreen(previewViewProvider = { preview })
    }
}