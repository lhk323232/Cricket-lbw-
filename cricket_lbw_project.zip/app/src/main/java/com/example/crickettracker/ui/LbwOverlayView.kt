package com.example.crickettracker.ui

import android.content.Context
import android.graphics.*
import android.util.AttributeSet
import android.view.View
import com.example.crickettracker.lbw.LbwDecision
import com.example.crickettracker.tracking.TrajectoryPhysics

class LbwOverlayView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    var fitResult: TrajectoryPhysics.FitResult? = null
    var lbwDecision: LbwDecision? = null
    var impactPoint: PointF? = null
    var bouncePoint: PointF? = null
    var worldToScreen: ((Double, Double, Double) -> PointF)? = null

    private val trajPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeWidth = 6f; color = Color.YELLOW
    }
    private val bouncePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.BLUE; style = Paint.Style.FILL }
    private val impactPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.MAGENTA; style = Paint.Style.FILL }
    private val stumpPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; strokeWidth = 8f }
    private val decisionPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { textSize = 60f; typeface = Typeface.DEFAULT_BOLD }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val fit = fitResult ?: return
        drawTrajectory(canvas, fit)
        bouncePoint?.let { canvas.drawCircle(it.x, it.y, 18f, bouncePaint) }
        impactPoint?.let { canvas.drawCircle(it.x, it.y, 18f, impactPaint) }
        drawStumps(canvas)
        drawDecision(canvas)
    }

    private fun drawTrajectory(canvas: Canvas, fit: TrajectoryPhysics.FitResult) {
        val map = worldToScreen ?: return
        // sample a reasonable X range around fit
        val minX = fit.X0
        val maxX = fit.X0 + fit.Vx * 1.5 // one second ahead approx
        val pts = TrajectoryPhysics.sampleTrajectory(fit, minX, maxX, 120)
        val path = Path()
        var started = false
        for (p in pts) {
            val screen = map(p.x, p.y, p.z)
            if (!started) { path.moveTo(screen.x, screen.y); started = true }
            else path.lineTo(screen.x, screen.y)
        }
        canvas.drawPath(path, trajPaint)
    }

    private fun drawStumps(canvas: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        val stumpGap = w * 0.03f
        val top = h * 0.25f; val bottom = h * 0.85f
        val center = w * 0.5f
        canvas.drawLine(center - stumpGap, top, center - stumpGap, bottom, stumpPaint)
        canvas.drawLine(center, top, center, bottom, stumpPaint)
        canvas.drawLine(center + stumpGap, top, center + stumpGap, bottom, stumpPaint)
    }

    private fun drawDecision(canvas: Canvas) {
        val d = lbwDecision ?: return
        decisionPaint.color = when (d.verdict) {
            com.example.crickettracker.lbw.Verdict.OUT -> Color.GREEN
            com.example.crickettracker.lbw.Verdict.NOT_OUT -> Color.RED
            else -> Color.YELLOW
        }
        canvas.drawText(d.verdict.name, 40f, height - 80f, decisionPaint)
        canvas.drawText("Conf: ${(d.confidence*100).toInt()}%", 40f, height - 20f, decisionPaint)
    }
}