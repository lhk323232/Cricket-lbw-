package com.example.crickettracker.ui

import android.graphics.PointF
import androidx.camera.view.PreviewView
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import com.example.crickettracker.lbw.LbwDecision
import com.example.crickettracker.tracking.TrajectoryPhysics

@Composable
fun LbwDecisionScreen(
    previewViewProvider: @Composable () -> PreviewView,
    worldToScreen: ((Double, Double, Double) -> PointF)? = null,
    onRequestRestartCalibration: () -> Unit = {}
) {
    var fitResult by remember { mutableStateOf<TrajectoryPhysics.FitResult?>(null) }
    var decision by remember { mutableStateOf<LbwDecision?>(null) }
    var impactPoint by remember { mutableStateOf<PointF?>(null) }
    var bouncePoint by remember { mutableStateOf<PointF?>(null) }

    Column(Modifier.fillMaxSize()) {
        Box(Modifier.weight(1f)) {
            AndroidView(factory = { previewViewProvider() }, modifier = Modifier.fillMaxSize())
            AndroidView(factory = { ctx ->
                val overlay = LbwOverlayView(ctx)
                overlay.worldToScreen = { x,y,z ->
                    worldToScreen?.invoke(x,y,z) ?: PointF((x*10+ctx.resources.displayMetrics.widthPixels/2).toFloat(), (ctx.resources.displayMetrics.heightPixels - (z*200).toFloat()))
                }
                overlay.fitResult = fitResult
                overlay.lbwDecision = decision
                overlay.impactPoint = impactPoint
                overlay.bouncePoint = bouncePoint
                overlay
            }, modifier = Modifier.fillMaxSize())
        }

        Row(Modifier.fillMaxWidth().padding(8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Card(modifier = Modifier.weight(1f)) {
                Column(Modifier.padding(12.dp)) {
                    Text("LBW Decision", style = MaterialTheme.typography.titleMedium)
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("Verdict: ${decision?.verdict ?: "—"}")
                    Text("Reason: ${decision?.reason ?: "—"}")
                    Text("Confidence: ${decision?.confidence?.let { "${(it*100).toInt()}%" } ?: "—"}")
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(onClick = {}) { Text("Re-evaluate") }
                        Button(onClick = onRequestRestartCalibration) { Text("Re-calibrate") }
                    }
                }
            }

            Card(modifier = Modifier.width(180.dp)) {
                Column(Modifier.padding(8.dp)) {
                    Text("Status")
                    Text("Fit RMS: ${fitResult?.rmsError?.let { String.format("%.3f", it) } ?: "—"}")
                    Spacer(modifier = Modifier.height(6.dp))
                    Button(onClick = {}) { Text("Save snapshot") }
                }
            }
        }
    }
}