package com.example.crickettracker.lbw

import com.example.crickettracker.tracking.TrajectoryPhysics
import kotlin.math.abs

data class LbwDecision(
    val verdict: Verdict,
    val reason: String,
    val confidence: Double
)

enum class Verdict { OUT, NOT_OUT, UNCERTAIN }

object LbwDecisionHelper {
    data class Config(
        val pitchTolerance: Double = 0.10,
        val impactTolerance: Double = 0.10,
        val stumpLateralTolerance: Double = 0.04,
        val stumpHeight: Double = 0.71,
        val stumpHalfWidth: Double = 0.1143
    )

    fun evaluate(
        fit: TrajectoryPhysics.FitResult,
        stumpX: Double,
        impactY: Double,
        bounceY: Double,
        config: Config = Config()
    ): LbwDecision {
        if (!pitchedInLine(bounceY, config)) {
            return LbwDecision(Verdict.NOT_OUT, "Ball pitched outside leg stump.", 1.0)
        }
        if (!impactInLine(impactY, config)) {
            return LbwDecision(Verdict.NOT_OUT, "Impact outside line of the stumps.", 1.0)
        }
        val pred = TrajectoryPhysics.predictAtStumpPlane(fit, stumpX)
        if (pred == null) {
            return LbwDecision(Verdict.UNCERTAIN, "Unable to project ball path reliably.", 0.3)
        }
        val hitStumpsVertically = pred.z in 0.0..config.stumpHeight
        val hitStumpsLaterally  = kotlin.math.abs(pred.y) <= (config.stumpHalfWidth + config.stumpLateralTolerance)
        if (hitStumpsVertically && hitStumpsLaterally) {
            val conf = computeConfidence(fit.rmsError)
            return LbwDecision(Verdict.OUT, "Projection shows ball hitting stumps.", conf)
        }
        return LbwDecision(Verdict.NOT_OUT, "Projected trajectory misses stumps.", computeConfidence(fit.rmsError))
    }

    private fun pitchedInLine(bounceY: Double, cfg: Config): Boolean {
        return abs(bounceY) <= (cfg.stumpHalfWidth + cfg.pitchTolerance)
    }

    private fun impactInLine(impactY: Double, cfg: Config): Boolean {
        return abs(impactY) <= (cfg.stumpHalfWidth + cfg.impactTolerance)
    }

    private fun computeConfidence(rmsError: Double): Double {
        return when {
            rmsError < 0.01 -> 1.0
            rmsError < 0.03 -> 0.85
            rmsError < 0.05 -> 0.6
            rmsError < 0.10 -> 0.4
            else -> 0.2
        }
    }
}